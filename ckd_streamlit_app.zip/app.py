
import streamlit as st
import pandas as pd
import joblib

# Load the trained model
model = joblib.load("tuned_balanced_rf_ckd.pkl")

st.set_page_config(page_title="CKD Prediction")
st.title("Chronic Kidney Disease Prediction")

st.write("Enter the patient's clinical data to predict the presence of Chronic Kidney Disease.")

# Input fields
age = st.number_input("Age", min_value=0, max_value=120)
bmi = st.number_input("BMI")
serumcreatinine = st.number_input("Serum Creatinine")
gfr = st.number_input("GFR")
systolicbp = st.number_input("Systolic Blood Pressure")
diastolicbp = st.number_input("Diastolic Blood Pressure")
hba1c = st.number_input("HbA1c")
bunlevels = st.number_input("BUN Levels")
cholesterolldl = st.number_input("LDL Cholesterol")
acr = st.number_input("ACR")

# Predict button
if st.button("Predict"):
    input_data = pd.DataFrame([[age, bmi, serumcreatinine, gfr, systolicbp,
                                diastolicbp, hba1c, bunlevels, cholesterolldl, acr]],
                              columns=['age', 'bmi', 'serumcreatinine', 'gfr', 'systolicbp',
                                       'diastolicbp', 'hba1c', 'bunlevels', 'cholesterolldl', 'acr'])

    prediction = model.predict(input_data)[0]

    if prediction == 1:
        st.error("Chronic Kidney Disease (CKD) Detected.")
    else:
        st.success("No CKD Detected.")
